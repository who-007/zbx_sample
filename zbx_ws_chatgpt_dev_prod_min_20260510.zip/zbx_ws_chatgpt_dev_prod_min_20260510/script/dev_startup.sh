#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd $(dirname $0); pwd)
ROOT_DIR=$(cd ${SCRIPT_DIR}/..; pwd)

docker compose -f ${ROOT_DIR}/env_dev/host_a/docker-compose.yml up -d
docker compose -f ${ROOT_DIR}/env_dev/host_b/docker-compose.yml up -d

echo "HostA: http://localhost:8080"
