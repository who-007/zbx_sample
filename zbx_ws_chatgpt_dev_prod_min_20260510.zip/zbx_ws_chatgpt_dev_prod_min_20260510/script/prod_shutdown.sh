#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 host_a|host_b"
  exit 1
fi

SCRIPT_DIR=$(cd $(dirname $0); pwd)
ROOT_DIR=$(cd ${SCRIPT_DIR}/..; pwd)

docker compose -f ${ROOT_DIR}/env_prod/$1/docker-compose.yml down
