#!/usr/bin/env bash
# =============================================================================
# docs/scripts/puml_to_svg.sh
# 役割: PlantUMLソース（.puml）をSVG画像に変換する
#
# 使い方:
#   bash docs/scripts/puml_to_svg.sh              # docs/puml/ 内の全.pumlを変換
#   bash docs/scripts/puml_to_svg.sh foo.puml     # 指定ファイルのみ変換
#
# 前提条件（いずれか1つが必要）:
#   A) plantuml コマンドがインストール済み
#        Ubuntu: sudo apt-get install -y plantuml
#   B) plantuml.jar が利用可能（PLANTUML_JAR 環境変数またはデフォルトパス）
#        java -jar plantuml.jar が実行可能なこと
#   C) Docker が利用可能
#        plantuml/plantuml イメージを使用
#
# 出力先: docs/picture/  (*.svg)
# ログ:   docs/scripts/logs/puml_to_svg.log
#
# 優先順位: plantuml コマンド > plantuml.jar (java) > Docker
# =============================================================================
set -euo pipefail

# ---- パス設定 ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
PUML_DIR="${DOCS_DIR}/puml"
SVG_DIR="${DOCS_DIR}/picture"
LOG_DIR="${SCRIPT_DIR}/logs"
LOGFILE="${LOG_DIR}/puml_to_svg.log"

# PlantUML jar のデフォルト検索パス（環境変数 PLANTUML_JAR で上書き可能）
PLANTUML_JAR="${PLANTUML_JAR:-/usr/share/plantuml/plantuml.jar}"

mkdir -p "${SVG_DIR}" "${LOG_DIR}"
exec > >(tee -a "${LOGFILE}") 2>&1

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()  { echo "$(timestamp) [puml_to_svg] $*"; }
ok()   { echo "$(timestamp) [puml_to_svg] ✓ $*"; }
err()  { echo "$(timestamp) [puml_to_svg] ✗ ERROR: $*" >&2; }

log "===== PlantUML → SVG 変換 開始 ====="
log "PUML 入力ディレクトリ : ${PUML_DIR}"
log "SVG  出力ディレクトリ : ${SVG_DIR}"

# ---- 変換コマンド決定 ----
CONVERT_CMD=""

if command -v plantuml >/dev/null 2>&1; then
    CONVERT_CMD="plantuml_cmd"
    log "変換エンジン: plantuml コマンド ($(plantuml -version 2>&1 | head -1))"
elif [ -f "${PLANTUML_JAR}" ] && command -v java >/dev/null 2>&1; then
    CONVERT_CMD="plantuml_jar"
    log "変換エンジン: plantuml.jar + Java ($(java -version 2>&1 | head -1))"
elif command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    CONVERT_CMD="plantuml_docker"
    log "変換エンジン: Docker (plantuml/plantuml)"
else
    err "変換エンジンが見つかりません。以下のいずれかをインストールしてください:"
    err "  A) sudo apt-get install -y plantuml"
    err "  B) plantuml.jar をダウンロードし PLANTUML_JAR=/path/to/plantuml.jar を設定"
    err "     例: PLANTUML_JAR=~/plantuml.jar bash docs/scripts/puml_to_svg.sh"
    err "  C) Docker CE をインストール・起動"
    exit 1
fi

# ---- 1ファイル変換関数 ----
convert_one() {
    local puml_file="$1"
    local basename
    basename="$(basename "${puml_file}" .puml)"
    local out_svg="${SVG_DIR}/${basename}.svg"

    log "変換中: $(basename "${puml_file}") → ${basename}.svg"

    case "${CONVERT_CMD}" in
        plantuml_cmd)
            plantuml -tsvg -o "${SVG_DIR}" "${puml_file}"
            ;;
        plantuml_jar)
            java -jar "${PLANTUML_JAR}" -tsvg -o "${SVG_DIR}" "${puml_file}"
            ;;
        plantuml_docker)
            # ファイルのあるディレクトリをマウントして変換
            local puml_dir
            puml_dir="$(dirname "$(realpath "${puml_file}")")"
            docker run --rm \
                -v "${puml_dir}:/work/puml:ro" \
                -v "${SVG_DIR}:/work/svg" \
                plantuml/plantuml \
                -tsvg -o /work/svg "/work/puml/$(basename "${puml_file}")"
            ;;
    esac

    if [ -f "${out_svg}" ]; then
        ok "${basename}.svg 生成完了"
        return 0
    else
        err "${basename}.svg の生成に失敗しました"
        return 1
    fi
}

# ---- 変換対象の決定 ----
SUCCESS=0
FAIL=0

if [ $# -eq 0 ]; then
    # 引数なし → docs/puml/ 内の全 .puml を変換
    if [ ! -d "${PUML_DIR}" ]; then
        err "PUMLディレクトリが見つかりません: ${PUML_DIR}"
        exit 1
    fi
    PUML_FILES=("${PUML_DIR}"/*.puml)
    if [ ${#PUML_FILES[@]} -eq 0 ] || [ ! -f "${PUML_FILES[0]}" ]; then
        err ".puml ファイルが見つかりません: ${PUML_DIR}/*.puml"
        exit 1
    fi
    log "対象ファイル数: ${#PUML_FILES[@]}"
    for puml in "${PUML_FILES[@]}"; do
        if convert_one "${puml}"; then
            SUCCESS=$((SUCCESS + 1))
        else
            FAIL=$((FAIL + 1))
        fi
    done
else
    # 引数あり → 指定ファイルを変換（絶対パス or PUML_DIR相対）
    for arg in "$@"; do
        if [ -f "${arg}" ]; then
            puml_path="${arg}"
        elif [ -f "${PUML_DIR}/${arg}" ]; then
            puml_path="${PUML_DIR}/${arg}"
        else
            err "ファイルが見つかりません: ${arg}"
            FAIL=$((FAIL + 1))
            continue
        fi
        if convert_one "${puml_path}"; then
            SUCCESS=$((SUCCESS + 1))
        else
            FAIL=$((FAIL + 1))
        fi
    done
fi

# ---- 結果サマリ ----
log ""
log "===== 変換結果 ====="
log "  成功: ${SUCCESS} 件"
log "  失敗: ${FAIL} 件"
log "  出力先: ${SVG_DIR}"
log "  ログ  : ${LOGFILE}"

if [ "${FAIL}" -gt 0 ]; then
    exit 1
fi

ok "全変換完了"
exit 0
