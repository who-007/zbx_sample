#!/usr/bin/env bash
# =============================================================================
# docs/scripts/md_to_pdf.sh
# 役割: Markdownファイル（.md）をPDFに変換する
#
# 使い方:
#   bash docs/scripts/md_to_pdf.sh              # docs/*.md を全て変換
#   bash docs/scripts/md_to_pdf.sh 02_基本設計書.md       # 1ファイル指定
#   bash docs/scripts/md_to_pdf.sh 02_基本設計書.md 03_詳細設計書.md  # 複数指定
#
# 前提条件:
#   - pandoc   : sudo apt-get install -y pandoc
#   - wkhtmltopdf : sudo apt-get install -y wkhtmltopdf
#
# 動作概要:
#   1. SVG参照パスを絶対パス（file:///...）に変換した一時MDを作成
#   2. pandoc で一時MD → HTML変換（日本語フォント・スタイル注入）
#   3. wkhtmltopdf で HTML → PDF変換
#
# 注意:
#   - SVG画像は docs/picture/ に存在する必要があります
#   - 日本語表示には "Noto Sans CJK JP" フォントを推奨します
#       Ubuntu: sudo apt-get install -y fonts-noto-cjk
#
# 出力先: docs/pdf/  (*.pdf)
# ログ:   docs/scripts/logs/md_to_pdf.log
# =============================================================================
set -euo pipefail

# ---- パス設定 ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
PICTURE_DIR="${DOCS_DIR}/picture"
PDF_DIR="${DOCS_DIR}/pdf"
LOG_DIR="${SCRIPT_DIR}/logs"
LOGFILE="${LOG_DIR}/md_to_pdf.log"

mkdir -p "${PDF_DIR}" "${LOG_DIR}"
exec > >(tee -a "${LOGFILE}") 2>&1

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()  { echo "$(timestamp) [md_to_pdf] $*"; }
ok()   { echo "$(timestamp) [md_to_pdf] ✓ $*"; }
err()  { echo "$(timestamp) [md_to_pdf] ✗ ERROR: $*" >&2; }

log "===== Markdown → PDF 変換 開始 ====="
log "MD  入力ディレクトリ : ${DOCS_DIR}"
log "PDF 出力ディレクトリ : ${PDF_DIR}"

# ---- 依存コマンド確認 ----
MISSING=()
command -v pandoc        >/dev/null 2>&1 || MISSING+=("pandoc")
command -v wkhtmltopdf  >/dev/null 2>&1 || MISSING+=("wkhtmltopdf")

if [ ${#MISSING[@]} -gt 0 ]; then
    err "以下のコマンドが見つかりません: ${MISSING[*]}"
    err "インストール方法:"
    err "  sudo apt-get install -y pandoc wkhtmltopdf"
    exit 1
fi

log "pandoc       : $(pandoc --version | head -1)"
log "wkhtmltopdf  : $(wkhtmltopdf --version 2>/dev/null | head -1)"

# ---- CSSスタイル定義 ----
CSS_FILE="$(mktemp /tmp/md_to_pdf_XXXXXX.css)"
cat > "${CSS_FILE}" <<'ENDCSS'
* { box-sizing: border-box; }
body {
  font-family: "Noto Sans CJK JP", "Noto Sans JP", "IPAGothic", "Meiryo", serif;
  font-size: 10.5pt;
  color: #222;
  line-height: 1.75;
  margin: 0;
  padding: 0;
}
h1 {
  font-size: 17pt;
  color: #1F497D;
  border-bottom: 3px solid #1F497D;
  padding-bottom: 5px;
  margin-top: 28px;
  page-break-after: avoid;
}
h2 {
  font-size: 13pt;
  color: #1F497D;
  border-left: 5px solid #1F497D;
  padding-left: 10px;
  margin-top: 22px;
  page-break-after: avoid;
}
h3 {
  font-size: 11pt;
  color: #2E6DA4;
  margin-top: 16px;
  page-break-after: avoid;
}
table {
  border-collapse: collapse;
  width: 100%;
  margin: 10px 0;
  font-size: 9.5pt;
  page-break-inside: avoid;
}
th {
  background: #1F497D;
  color: #ffffff;
  padding: 6px 9px;
  text-align: left;
  font-weight: bold;
}
td {
  border: 1px solid #BBCCE0;
  padding: 5px 9px;
  vertical-align: top;
}
tr:nth-child(even) td { background: #DEEAF1; }
code {
  font-family: "Courier New", "Courier", monospace;
  font-size: 8.5pt;
  background: #F4F4F4;
  border: 1px solid #DDD;
  border-radius: 3px;
  padding: 1px 5px;
}
pre {
  font-family: "Courier New", "Courier", monospace;
  font-size: 8.5pt;
  background: #F4F4F4;
  border: 1px solid #DDD;
  border-radius: 4px;
  padding: 10px 12px;
  white-space: pre-wrap;
  word-wrap: break-word;
  overflow-x: auto;
  page-break-inside: avoid;
}
pre code { background: none; border: none; padding: 0; }
img { max-width: 100%; height: auto; display: block; margin: 10px auto; page-break-inside: avoid; }
ul, ol { padding-left: 1.6em; }
li { margin: 3px 0; }
blockquote {
  border-left: 4px solid #1F497D;
  margin: 8px 0;
  padding: 6px 12px;
  background: #EEF4FF;
  color: #333;
}
hr { border: none; border-top: 2px solid #DDEEFF; margin: 18px 0; }
a { color: #2E6DA4; }
ENDCSS

# ---- フォント強制指定（HTMLインジェクション用） ----
FONT_INJECT='<style>
body,table,th,td,h1,h2,h3,h4,h5,p,li,pre,code,blockquote {
  font-family: "Noto Sans CJK JP","Noto Sans JP","IPAGothic","Meiryo",serif !important;
}
</style>'

# ---- 1ファイル変換関数 ----
convert_one() {
    local md_path="$1"
    local md_file
    md_file="$(basename "${md_path}")"
    local base="${md_file%.md}"
    local pdf_path="${PDF_DIR}/${base}.pdf"
    local tmp_md
    tmp_md="$(mktemp /tmp/md_pdf_XXXXXX.md)"
    local tmp_html
    tmp_html="$(mktemp /tmp/md_pdf_XXXXXX.html)"

    log "変換中: ${md_file} → ${base}.pdf"

    # Step 1: SVG相対パス（picture/）を絶対パス（file:///...）に変換
    #         wkhtmltopdf はローカル相対参照が効かないため絶対パスが必要
    sed "s|picture/|file://${PICTURE_DIR}/|g" "${md_path}" > "${tmp_md}"

    # Step 2: YAMLフロントマターでタイトルを設定
    #         mdファイルに既にフロントマターがある場合は上書き
    local title
    # h1見出しからタイトルを抽出（なければファイル名を使用）
    title="$(grep -m1 '^# ' "${md_path}" | sed 's/^# //' || true)"
    [ -z "${title}" ] && title="${base}"

    local tmp_md2
    tmp_md2="$(mktemp /tmp/md_pdf2_XXXXXX.md)"
    {
        printf -- '---\n'
        printf 'title: "%s"\n' "${title}"
        printf 'lang: ja\n'
        printf -- '---\n\n'
        cat "${tmp_md}"
    } > "${tmp_md2}"

    # Step 3: pandoc で Markdown → HTML 変換
    if ! pandoc "${tmp_md2}" \
        --standalone \
        --to=html5 \
        --css="${CSS_FILE}" \
        -o "${tmp_html}" 2>/dev/null; then
        err "${md_file}: pandoc 変換失敗"
        rm -f "${tmp_md}" "${tmp_md2}" "${tmp_html}"
        return 1
    fi

    # Step 4: HTMLのタイトル文字化け修正・フォント強制注入
    python3 - "${tmp_html}" "${title}" "${FONT_INJECT}" <<'PYEOF'
import sys, re
html_path = sys.argv[1]
title     = sys.argv[2]
font_css  = sys.argv[3]
import html as hmod

with open(html_path, "r", encoding="utf-8") as f:
    content = f.read()

# <title> タグを正しいタイトルに置換
content = re.sub(
    r'<title>[^<]*</title>',
    f'<title>{hmod.escape(title)}</title>',
    content
)
# フォント強制指定を </head> の直前に注入
content = content.replace('</head>', font_css + '\n</head>')

with open(html_path, "w", encoding="utf-8") as f:
    f.write(content)
PYEOF

    # Step 5: wkhtmltopdf で HTML → PDF 変換
    if ! wkhtmltopdf \
        --quiet \
        --page-size A4 \
        --margin-top    15mm \
        --margin-bottom 15mm \
        --margin-left   18mm \
        --margin-right  18mm \
        --encoding UTF-8 \
        --enable-local-file-access \
        --disable-smart-shrinking \
        "${tmp_html}" "${pdf_path}" 2>/dev/null; then
        err "${md_file}: wkhtmltopdf 変換失敗"
        rm -f "${tmp_md}" "${tmp_md2}" "${tmp_html}"
        return 1
    fi

    rm -f "${tmp_md}" "${tmp_md2}" "${tmp_html}"

    if [ -f "${pdf_path}" ]; then
        local size
        size="$(du -h "${pdf_path}" | cut -f1)"
        ok "${base}.pdf 生成完了 (${size})"
        return 0
    else
        err "${base}.pdf が生成されませんでした"
        return 1
    fi
}

# ---- 変換対象の決定 ----
SUCCESS=0
FAIL=0

if [ $# -eq 0 ]; then
    # 引数なし → docs/ 内の全 .md を変換
    MD_FILES=("${DOCS_DIR}"/*.md)
    if [ ${#MD_FILES[@]} -eq 0 ] || [ ! -f "${MD_FILES[0]}" ]; then
        err ".md ファイルが見つかりません: ${DOCS_DIR}/*.md"
        exit 1
    fi
    log "対象ファイル数: ${#MD_FILES[@]}"
    for md in "${MD_FILES[@]}"; do
        if convert_one "${md}"; then
            SUCCESS=$((SUCCESS + 1))
        else
            FAIL=$((FAIL + 1))
        fi
    done
else
    # 引数あり → 指定ファイルを変換（絶対パス or DOCS_DIR相対）
    for arg in "$@"; do
        if [ -f "${arg}" ]; then
            md_path="${arg}"
        elif [ -f "${DOCS_DIR}/${arg}" ]; then
            md_path="${DOCS_DIR}/${arg}"
        else
            err "ファイルが見つかりません: ${arg}"
            FAIL=$((FAIL + 1))
            continue
        fi
        if convert_one "${md_path}"; then
            SUCCESS=$((SUCCESS + 1))
        else
            FAIL=$((FAIL + 1))
        fi
    done
fi

# ---- 後片付け ----
rm -f "${CSS_FILE}"

# ---- 結果サマリ ----
log ""
log "===== 変換結果 ====="
log "  成功: ${SUCCESS} 件"
log "  失敗: ${FAIL} 件"
log "  出力先: ${PDF_DIR}"
log "  ログ  : ${LOGFILE}"

if [ "${FAIL}" -gt 0 ]; then
    exit 1
fi

ok "全変換完了"
exit 0
