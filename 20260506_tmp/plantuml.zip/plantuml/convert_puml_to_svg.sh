#!/bin/bash

# convert_puml_to_svg.sh
# PlantUMLサーバーに対して、指定したディレクトリ内の.pumlファイルをSVG形式に変換するスクリプト
# 使い方:
#   ./convert_puml_to_svg.sh [target_directory]
#   - target_directory: 変換対象のディレクトリ（省略した場合は「puml/」）


# 設定：PlantUMLサーバーのURL
SERVER_URL="http://localhost:8080/svg"
# 文字をパス（図形）に変換して出力する設定
#SERVER_URL="http://localhost:8080/svg?-tpath"
echo "Using PlantUML server at: $SERVER_URL"

# 引数でディレクトリ指定がない場合は「puml/」を対象にする
TARGET_DIR="${1:-puml}"

# 対象ディレクトリが存在するかチェック
if [ ! -d "$TARGET_DIR" ]; then
  echo "Error: Directory '$TARGET_DIR' not found."
  exit 1
fi

echo "Converting .puml files in '$TARGET_DIR' to SVG..."

# ループ処理
for file in "$TARGET_DIR"/*.{puml,pu} ; do
  # ファイルが存在しない場合の例外処理
  [ -e "$file" ] || continue
  echo "Processing    : $file"
#  echo "Processing: $file -> $output"

  # 出力ファイル名の作成 (例: puml/test.puml -> puml/test.svg)
  output="${file%.*}.svg"


  # POSTリクエストでSVGを取得
  curl -s -X POST \
    -H "Content-Type: text/plain; charset=UTF-8" \
    --data-binary @"$file" "$SERVER_URL/" > "$output"

  # 成功判定（ファイルサイズが0より大きいか）
  if [ -s "$output" ]; then
    echo "  [OK] Success: $output"
  else
    echo "  [ERROR] Failed to convert $file"
    rm -f "$output"
  fi
done

echo "Done!"
