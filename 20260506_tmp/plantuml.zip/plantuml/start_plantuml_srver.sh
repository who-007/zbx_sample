#!/bin/bash

# start plantUML server
#docker run -d -p 8080:8080 plantuml/plantuml-server:jetty
#docker run -d -p 8080:8080 -e PLANTUML_SECURITY_PROFILE=UNSECURE plantuml/plantuml-server
docker run -d -p 8080:8080 \
  -e PLANTUML_SECURITY_PROFILE=UNSECURE \
  --name plantuml_server \
  -v ${HOME}/work/plantuml/data:/data \
  plantuml/plantuml-server:jetty

#docker run -d -p 8080:8080 \
#  -e PLANTUML_SECURITY_PROFILE=UNSECURE \
#  -v "あなたのプロジェクトパス:/data" \
#  plantuml/plantuml-server:jetty
