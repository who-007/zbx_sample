#!/usr/bin/env bash

set -euo pipefail

echo
echo "=================================="
echo " DevContainer Ready"
echo "=================================="

echo "Workspace : /workspace"

echo
docker compose version || true