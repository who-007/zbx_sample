#!/usr/bin/env bash

set -euo pipefail

sudo apt-get update

# Install tools(packages.txtから読み込んでインストール)
sed  's/#.*//g' /workspace/.devcontainer/packages.txt \
| xargs  sudo apt-get install -y

sudo apt-get clean
sudo rm -rf /var/lib/apt/lists/* 
