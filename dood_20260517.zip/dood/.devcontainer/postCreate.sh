#!/usr/bin/env bash

set -euo pipefail

echo "[INFO] Install tools..."
bash /workspace/.devcontainer/install_tools.sh

echo "[INFO] bashrc_append"
cat /workspace/.devcontainer/bashrc.append >> ~/.bashrc

echo "[INFO] Docker"
docker version

echo "[INFO] Docker Compose"
docker compose version

echo "[INFO] Finished"