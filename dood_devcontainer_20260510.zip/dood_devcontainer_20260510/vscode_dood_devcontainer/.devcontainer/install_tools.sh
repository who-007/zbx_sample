#!/usr/bin/env bash

set -euo pipefail

apt-get update

# Install tools(packages.txtから読み込んでインストール)
sed  's/#.*//g' /workspace/.devcontainer/packages.txt \
| xargs apt-get install -y

#xargs -a /workspace/.devcontainer/packages.txt apt-get install -y

apt-get clean