#!/usr/bin/env bash

set -euo pipefail

echo "[INFO] Install tools..."
bash .devcontainer/install_tools.sh

echo "[INFO] Locale check"
bash .devcontainer/locale_check.sh

echo "[INFO] Docker"
docker version

echo "[INFO] Docker Compose"
docker compose version

echo "[INFO] Finished"