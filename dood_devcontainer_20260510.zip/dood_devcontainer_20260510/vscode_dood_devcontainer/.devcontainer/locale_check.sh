 #!/usr/bin/env bash
#
# =========================================================
# locale_check.sh
# =========================================================
#
# Japanese locale verification
#
# =========================================================

set -euo pipefail

echo
echo "========================================="
echo " Locale Check"
echo "========================================="

echo
echo "[INFO] locale"

locale

echo
echo "[INFO] timezone"

date

echo
echo "[INFO] UTF-8 test"

echo "日本語 UTF-8 テスト"

echo
echo "[INFO] current language"

echo "${LANG}"

echo
echo "[INFO] current locale"

locale charmap