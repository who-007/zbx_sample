# VSCode DevContainer + DooD

## Usage

Open with VSCode and execute:

- Reopen in Container

## Verify

```bash
docker ps
docker compose version
locale
```
