#!/bin/bash
# host-w コンテナ起動スクリプト

# SNMPd 起動
service snmpd start

# Apache 起動
service apache2 start

# Zabbix Agent2 起動（インストール済みの場合）
if command -v zabbix_agent2 >/dev/null 2>&1; then
  zabbix_agent2 -c /etc/zabbix/zabbix_agent2.conf &
  echo "Zabbix Agent2 起動しました"
fi

echo "HostW コンテナ 起動完了"
echo "SNMP: udp/161, HTTP: tcp/80, Zabbix Agent: tcp/10050"

# フォアグラウンドで待機
tail -f /dev/null
