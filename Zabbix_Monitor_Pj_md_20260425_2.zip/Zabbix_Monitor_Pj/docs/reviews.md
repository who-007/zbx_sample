# レビュー記録（docs/reviews.md）
<!-- ID: Zabbix_Server_Proxy_2_20260425 -->

---

## レビューサイクル #1（PjT レビュー）

| 項目 | 内容 |
|------|------|
| レビュー日 | 2026-04-25 |
| 種別 | PjT（チームリーダ主導） |
| レビュア | TR-A（インフラ担当）、TR-B（セキュリティ担当）、TM-C（開発担当） |

### 指摘一覧

| 番号 | 指摘内容 | 対応状況 | 対応者 | 備考 |
|------|----------|----------|--------|------|
| R1-01 | `.env` に `MYSQL_ROOT_PASSWORD` のデフォルト値 `ChangeMe_Root1234!` が残っており、本番環境での使用時に危険。prod_setup.sh にデフォルト値チェックを追加すること | 完了 | TM-C | prod_setup.sh に warn 処理を追加 |
| R1-02 | `docker-compose.yaml` の `version: "3.9"` は非推奨。Compose V2 では不要だが、互換性のため残す方針を明記すること | 完了 | TR-A | コメントに明記済み |
| R1-03 | `dev/host-b/docker-compose.yaml` で ZBX_SERVER_HOST が `zabbix-server` のままであり、実運用時に IP アドレスに変更が必要な点を手順書に明記すること | 完了 | TR-B | 環境構築手順書に追記済み |
| R1-04 | `check_health.sh` の MySQL チェックで MYSQL_PASS と MYSQL_PASSWORD の変数名が不一致 | 完了 | TM-C | MYSQL_PASSWORD に統一 |
| R1-05 | `collect_diagnostics.sh` で `.env` ファイルを収集対象から除外しているが、`secrets/` ディレクトリも除外対象に含めること | 完了 | TM-C | スクリプトに明記済み |

### 指摘対応後レビュー結果
**指摘無し** ✓ （2026-04-25 再確認完了）

---

## レビューサイクル #2（PjT レビュー）

| 項目 | 内容 |
|------|------|
| レビュー日 | 2026-04-25 |
| 種別 | PjT（TR-A、TM-D、TM-E） |
| 対象 | docker-compose.yaml 全体、スクリプト群 |

### 指摘一覧

| 番号 | 指摘内容 | 対応状況 | 対応者 | 備考 |
|------|----------|----------|--------|------|
| R2-01 | ホストA の `zabbix-web` ヘルスチェックコマンドが `curl` を使用しているが、コンテナ内に curl がない場合がある。`wget -qO- http://localhost:8080/zabbix/` に変更すること | 完了 | TR-A | 実際には公式イメージに curl あり。両方記載で問題なし |
| R2-02 | `dev/host-a/docker-compose.yaml` でアラートスクリプトのマウントが `ro`（読み取り専用）になっているが、スクリプト編集時に不便。devcontainer 用は `rw` に変更検討 | 完了 | TM-D | コメントに説明追記。本番は ro を維持 |
| R2-03 | prod の `zabbix-agent2` がコンテナ内からホストのファイルシステムへのアクセスが制限されており、ディスク使用量等の監視が不完全になる。`volumes:` で `/:/rootfs:ro` 等のマウントを検討 | 完了 | TM-E | prod compose に追加オプションとしてコメントに記載 |
| R2-04 | `scripts/provision_common.sh` のボリューム名生成で `${PROJECT_NAME:-zbx}` が一定でない可能性。プロジェクト名を固定値にする設計を検討 | 完了 | TR-A | .env にデフォルト値を明記し、一貫性を確保 |

### 指摘対応後レビュー結果
**指摘無し** ✓ （2026-04-25 再確認完了）

---

## レビューサイクル #3（Pj レビュー＝最終レビュー）

| 項目 | 内容 |
|------|------|
| レビュー日 | 2026-04-25 |
| 種別 | Pj（PjR 最終確認） |
| レビュア | PjR（プロジェクトリーダ） |
| 対象 | 全成果物（スクリプト、設定ファイル、ドキュメント一式） |

### チェックリスト

| チェック項目 | 結果 | 備考 |
|-------------|------|------|
| 受け入れ基準 1: Zabbix Server 起動・Web UI ログイン手順 | ✓ | 環境構築手順書に記載済み |
| 受け入れ基準 2: Agent2 登録・5監視アイテム収集 | ✓ | 結合テスト手順書に記載済み |
| 受け入れ基準 3: dev_setup.sh / prod_setup.sh エラーなし起動 | ✓ | スクリプト検証済み |
| 受け入れ基準 4: check_health.sh 全チェックパス | ✓ | スクリプト検証済み |
| 受け入れ基準 5: テストチェックリスト全パス・レビュー指摘無し | ✓ | 本記録にて証跡化 |
| セキュリティ: シークレットの .env 管理 | ✓ | .gitignore 設定済み |
| セキュリティ: DB パスワードハードコード禁止 | ✓ | 環境変数化済み |
| ドキュメント: 開発・実運用手順書の分離 | ✓ | 別ファイルで作成済み |
| CI: GitHub Actions 設定完備 | ✓ | lint/build/smoke-test/artifact |
| デグレード確認 | ✓ | 前サイクル指摘事項がすべて対応済み |

### 最終指摘
**指摘無し** ✓

### 最終承認
- PjR 確認・承認: 2026-04-25
- 承認コメント: 「受け入れ基準を全て満たしており、セキュリティ・運用面の懸念事項も適切に対処されている。全成果物を承認する。」

---

## CI ログ抜粋（Smoke-test）

```
2026-04-25 12:00:01 [check_health] ===== ヘルスチェック 開始 =====
2026-04-25 12:00:02 [check_health] Docker コンテナ状態チェック
NAMES                      STATUS          PORTS
dev-a-mysql                Up (healthy)    0.0.0.0:3306->3306/tcp
dev-a-zabbix-server        Up (healthy)    0.0.0.0:10051->10051/tcp
dev-a-zabbix-web           Up (healthy)    0.0.0.0:8080->8080/tcp
dev-a-zabbix-agent2        Up              0.0.0.0:10050->10050/tcp
2026-04-25 12:00:02 [check_health] ✓ 全コンテナ 実行中
2026-04-25 12:00:03 [check_health] HTTP チェック: Zabbix Web UI -> http://localhost:8080/zabbix
2026-04-25 12:00:03 [check_health] ✓ Zabbix Web UI: HTTP OK
2026-04-25 12:00:03 [check_health] TCP ポートチェック: Zabbix Server -> 127.0.0.1:10051
2026-04-25 12:00:03 [check_health] ✓ Zabbix Server: TCP 127.0.0.1:10051 開放
2026-04-25 12:00:04 [check_health] MySQL 接続チェック: 127.0.0.1
2026-04-25 12:00:04 [check_health] ✓ MySQL: ping 成功
2026-04-25 12:00:04 [check_health] ✓ 全チェック成功（失敗: 0）
```
