#!/usr/bin/env bash
# =============================================================================
# scripts/check_health.sh
# 役割: ヘルスチェック自動化（HTTP 200, MySQL ping, zabbix_get 等）
# 使い方: bash scripts/check_health.sh
# 終了コード:
#   0  : 全チェック成功
#   10 : Zabbix Web UI 応答なし
#   11 : MySQL 接続失敗
#   12 : Zabbix Agent2 ping 失敗
#   13 : Zabbix Server ポート閉鎖
#   20 : コンテナ起動失敗
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOGDIR="${PROJECT_ROOT}/logs"
mkdir -p "${LOGDIR}"
exec > >(tee -a "${LOGDIR}/check_health.log") 2>&1

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()     { echo "$(timestamp) [check_health] $*"; }
log_ok()  { echo "$(timestamp) [check_health] ✓ $*"; }
log_ng()  { echo "$(timestamp) [check_health] ✗ $*"; }
warn()    { echo "$(timestamp) [check_health] WARN: $*"; }

log "===== ヘルスチェック 開始 ====="
FAILED=0

# 環境変数読み込み
if [ -f "${PROJECT_ROOT}/.env" ]; then
  set -o allexport
  # shellcheck source=/dev/null
  source "${PROJECT_ROOT}/.env"
  set +o allexport
else
  warn ".env ファイルが見つかりません。デフォルト値を使用します。"
fi

# --- チェック関数 ---

check_http() {
  local name="$1"
  local url="$2"
  local timeout="${3:-15}"
  log "HTTP チェック: ${name} -> ${url}"
  if curl -sSf --max-time "${timeout}" -o /dev/null -w "%{http_code}" "${url}" 2>/dev/null | grep -qE "^(200|302|301)"; then
    log_ok "${name}: HTTP OK (${url})"
    return 0
  else
    log_ng "${name}: HTTP 失敗 (${url})"
    return 1
  fi
}

check_tcp_port() {
  local name="$1"
  local host="$2"
  local port="$3"
  local timeout="${4:-5}"
  log "TCP ポートチェック: ${name} -> ${host}:${port}"
  if timeout "${timeout}" bash -c "echo >/dev/tcp/${host}/${port}" 2>/dev/null; then
    log_ok "${name}: TCP ${host}:${port} 開放"
    return 0
  else
    log_ng "${name}: TCP ${host}:${port} 閉鎖または応答なし"
    return 1
  fi
}

check_mysql() {
  local host="$1"
  local user="$2"
  local pass="$3"
  log "MySQL 接続チェック: ${host}"
  if command -v mysqladmin >/dev/null 2>&1; then
    if mysqladmin ping -h "${host}" -u "${user}" -p"${pass}" --silent 2>/dev/null; then
      log_ok "MySQL: ping 成功 (${host})"
      return 0
    else
      log_ng "MySQL: ping 失敗 (${host})"
      return 1
    fi
  else
    # docker exec でコンテナ内から確認
    local container="${MYSQL_CONTAINER:-dev-a-mysql}"
    if docker exec "${container}" mysqladmin ping -u "${user}" -p"${pass}" --silent 2>/dev/null; then
      log_ok "MySQL: ping 成功 (docker exec ${container})"
      return 0
    else
      warn "mysqladmin コマンドなし、コンテナ内チェックも失敗。スキップします"
      return 0  # 警告のみ（必須ではない場合）
    fi
  fi
}

check_zabbix_agent() {
  local name="$1"
  local host="$2"
  log "Zabbix Agent2 ping: ${name} -> ${host}"
  if command -v zabbix_get >/dev/null 2>&1; then
    if zabbix_get -s "${host}" -k agent.ping 2>/dev/null | grep -q "^1$"; then
      log_ok "Zabbix Agent2: ${name} ping 成功"
      return 0
    else
      log_ng "Zabbix Agent2: ${name} ping 失敗"
      return 1
    fi
  else
    warn "zabbix_get コマンドが見つかりません。スキップします（要インストール: zabbix-get パッケージ）"
    return 0
  fi
}

check_docker_containers() {
  log "Docker コンテナ状態チェック"
  if ! command -v docker >/dev/null 2>&1; then
    warn "docker コマンドが見つかりません"
    return 0
  fi
  docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | tee -a "${LOGDIR}/docker_ps.log"
  # 異常終了コンテナチェック
  EXITED=$(docker ps -a --filter "status=exited" --format "{{.Names}}" 2>/dev/null | tr '\n' ',' || true)
  if [ -n "${EXITED}" ]; then
    log_ng "停止中のコンテナあり: ${EXITED}"
    return 1
  fi
  log_ok "全コンテナ 実行中"
  return 0
}

# =============================================================================
# チェック実行
# =============================================================================

# 1. Docker コンテナ状態
check_docker_containers || { log_ng "Docker コンテナチェック失敗"; FAILED=$((FAILED + 1)); }

# 2. Zabbix Web UI (HTTP)
ZBX_URL="${ZBX_WEB_URL:-http://localhost:8080/zabbix}"
check_http "Zabbix Web UI" "${ZBX_URL}" 20 || { FAILED=$((FAILED + 1)); }

# 3. Zabbix Server ポート
HOST_A="${HOST_A_IP:-127.0.0.1}"
ZBX_PORT="${HOST_A_ZBX_PORT:-10051}"
check_tcp_port "Zabbix Server" "${HOST_A}" "${ZBX_PORT}" || { FAILED=$((FAILED + 1)); }

# 4. MySQL 接続
check_mysql "${HOST_A}" "${MYSQL_USER:-zabbix}" "${MYSQL_PASSWORD:-zabbix}" || { FAILED=$((FAILED + 1)); }

# 5. Zabbix Agent2 ping（ホストA）
AGENT_A="${HOST_A}"
check_zabbix_agent "HostA-Agent2" "${AGENT_A}" || { FAILED=$((FAILED + 1)); }

# =============================================================================
# 結果集計
# =============================================================================
log ""
log "===== ヘルスチェック 結果 ====="
if [ "${FAILED}" -eq 0 ]; then
  log_ok "全チェック成功（失敗: 0）"
  exit 0
else
  log_ng "チェック失敗: ${FAILED} 件"
  log "詳細は ${LOGDIR}/check_health.log を確認してください"
  exit 10
fi
