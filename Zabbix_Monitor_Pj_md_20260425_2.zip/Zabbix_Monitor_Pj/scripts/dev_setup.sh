#!/usr/bin/env bash
# =============================================================================
# scripts/dev_setup.sh
# 役割: 開発環境一括構築（Dockerコンテナ起動～ヘルスチェックまで）
# 使い方: bash scripts/dev_setup.sh
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOGDIR="${PROJECT_ROOT}/logs"
mkdir -p "${LOGDIR}"
exec > >(tee -a "${LOGDIR}/dev_setup.log") 2>&1

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()  { echo "$(timestamp) [dev_setup] $*"; }
err()  { echo "$(timestamp) [dev_setup] ERROR: $*" >&2; exit 1; }
warn() { echo "$(timestamp) [dev_setup] WARN:  $*"; }

log "===== 開発環境 セットアップ 開始 ====="
log "プロジェクトルート: ${PROJECT_ROOT}"

# --- 1. 共通プロビジョニング ---
log "--- Step 1: 共通プロビジョニング ---"
bash "${SCRIPT_DIR}/provision_common.sh" || err "provision_common.sh が失敗しました"

# 環境変数読み込み
set -o allexport
# shellcheck source=/dev/null
source "${PROJECT_ROOT}/.env"
set +o allexport

# --- 2. docker-compose の確認 ---
log "--- Step 2: docker-compose コマンド確認 ---"
COMPOSE_CMD=""
if command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD="docker-compose"
  log "docker-compose v1 を使用します"
elif docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD="docker compose"
  log "docker compose v2 を使用します"
else
  err "docker-compose / docker compose コマンドが見つかりません"
fi

# --- 3. DevContainer の案内 ---
if [ -f "${PROJECT_ROOT}/dev/.devcontainer/devcontainer.json" ]; then
  log "--- Step 3: DevContainer ---"
  log ".devcontainer が検出されました"
  log "VSCode でプロジェクトを開き、「コンテナで再度開く（Reopen in Container）」を実行してください"
fi

# --- 4. 開発環境 docker-compose 起動 ---
log "--- Step 4: 開発用コンテナ起動 ---"

# ホストA 起動
COMPOSE_A="${PROJECT_ROOT}/dev/host-a/docker-compose.yaml"
if [ ! -f "${COMPOSE_A}" ]; then
  err "ファイルが見つかりません: ${COMPOSE_A}"
fi
log "ホストA コンテナ起動中..."
${COMPOSE_CMD} -f "${COMPOSE_A}" --env-file "${PROJECT_ROOT}/.env" up -d --build
log "ホストA コンテナ起動 完了"

# ホストB 起動
COMPOSE_B="${PROJECT_ROOT}/dev/host-b/docker-compose.yaml"
if [ ! -f "${COMPOSE_B}" ]; then
  err "ファイルが見つかりません: ${COMPOSE_B}"
fi
log "ホストB コンテナ起動中..."
${COMPOSE_CMD} -f "${COMPOSE_B}" --env-file "${PROJECT_ROOT}/.env" up -d --build
log "ホストB コンテナ起動 完了"

# ホストW（テスト用監視対象） 起動
COMPOSE_W="${PROJECT_ROOT}/dev/host-w/docker-compose.yaml"
if [ -f "${COMPOSE_W}" ]; then
  log "ホストW コンテナ起動中..."
  ${COMPOSE_CMD} -f "${COMPOSE_W}" --env-file "${PROJECT_ROOT}/.env" up -d --build
  log "ホストW コンテナ起動 完了"
else
  warn "ホストW の docker-compose.yaml が見つかりません。スキップします"
fi

# --- 5. サービス起動待ち ---
log "--- Step 5: サービス起動待ち（30秒）---"
log "MySQL/Zabbix Server の初期化を待機しています..."
sleep 30

# --- 6. ヘルスチェック ---
log "--- Step 6: ヘルスチェック実行 ---"
bash "${SCRIPT_DIR}/check_health.sh" || {
  warn "ヘルスチェックで一部失敗があります。logs/check_health.log を確認してください。"
  warn "サービスの起動に時間がかかる場合があります。しばらく待ってから再実行してください。"
  exit 4
}

# --- 7. 完了メッセージ ---
log "===== 開発環境 セットアップ 完了 ====="
log ""
log "【次のステップ】"
log "  Zabbix Web UI: ${ZBX_WEB_URL:-http://localhost:8080/zabbix}"
log "  初回ログイン: Admin / zabbix"
log "  ヘルスチェック再実行: bash scripts/check_health.sh"
log "  ログ確認: logs/ ディレクトリ"
log ""

exit 0
