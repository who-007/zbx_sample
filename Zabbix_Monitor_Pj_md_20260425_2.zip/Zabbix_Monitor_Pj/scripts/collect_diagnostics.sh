#!/usr/bin/env bash
# =============================================================================
# scripts/collect_diagnostics.sh
# 役割: 障害時ログ・設定収集（ZIP出力）
# 使い方: bash scripts/collect_diagnostics.sh
# 出力:  diagnostics_YYYYMMDD_HHMMSS.zip
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
DIAG_DIR="${PROJECT_ROOT}/diagnostics_${TIMESTAMP}"
ZIP_FILE="${PROJECT_ROOT}/diagnostics_${TIMESTAMP}.zip"

mkdir -p "${DIAG_DIR}"
LOGDIR="${PROJECT_ROOT}/logs"
mkdir -p "${LOGDIR}"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log() { echo "$(timestamp) [collect_diagnostics] $*" | tee -a "${LOGDIR}/collect_diagnostics.log"; }

log "===== 診断情報収集 開始 ====="
log "収集先: ${DIAG_DIR}"

# --- 1. Docker コンテナ状態 ---
log "Docker コンテナ状態 収集中..."
docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.Ports}}" \
  > "${DIAG_DIR}/docker_ps.txt" 2>&1 || true
docker stats --no-stream > "${DIAG_DIR}/docker_stats.txt" 2>&1 || true
docker network ls > "${DIAG_DIR}/docker_networks.txt" 2>&1 || true
docker volume ls > "${DIAG_DIR}/docker_volumes.txt" 2>&1 || true

# --- 2. コンテナログ収集 ---
log "コンテナログ 収集中..."
mkdir -p "${DIAG_DIR}/container_logs"
for CONTAINER in $(docker ps --format "{{.Names}}" 2>/dev/null); do
  docker logs --tail 200 "${CONTAINER}" > "${DIAG_DIR}/container_logs/${CONTAINER}.log" 2>&1 || true
  log "  ${CONTAINER} ログ収集 完了"
done

# --- 3. アプリケーションログ ---
log "アプリケーションログ 収集中..."
if [ -d "${LOGDIR}" ]; then
  cp -r "${LOGDIR}" "${DIAG_DIR}/logs" 2>/dev/null || true
fi

# --- 4. 設定ファイル（シークレット除外） ---
log "設定ファイル 収集中（シークレット除外）..."
mkdir -p "${DIAG_DIR}/configs"
# .env は除外（機密情報含む）
cp "${PROJECT_ROOT}/.env.example" "${DIAG_DIR}/configs/" 2>/dev/null || true

# docker-compose.yaml のみ収集
find "${PROJECT_ROOT}/dev" "${PROJECT_ROOT}/prod" -name "docker-compose.yaml" 2>/dev/null | while read -r f; do
  DEST="${DIAG_DIR}/configs/$(echo "${f}" | sed "s|${PROJECT_ROOT}/||" | tr '/' '_')"
  cp "${f}" "${DEST}" 2>/dev/null || true
done

# --- 5. システム情報 ---
log "システム情報 収集中..."
{
  echo "=== 収集日時 ==="
  date
  echo ""
  echo "=== OS情報 ==="
  cat /etc/os-release 2>/dev/null || true
  echo ""
  echo "=== カーネル ==="
  uname -a
  echo ""
  echo "=== ディスク使用量 ==="
  df -h
  echo ""
  echo "=== メモリ使用量 ==="
  free -h
  echo ""
  echo "=== Docker バージョン ==="
  docker --version
  docker compose version 2>/dev/null || docker-compose --version 2>/dev/null || true
} > "${DIAG_DIR}/system_info.txt" 2>&1

# --- 6. ヘルスチェック実行結果 ---
log "ヘルスチェック実行中..."
bash "${SCRIPT_DIR}/check_health.sh" > "${DIAG_DIR}/health_check_result.txt" 2>&1 || true

# --- 7. ZIP 圧縮 ---
log "ZIP 圧縮中..."
cd "${PROJECT_ROOT}"
zip -r "${ZIP_FILE}" "diagnostics_${TIMESTAMP}/" >/dev/null
rm -rf "${DIAG_DIR}"

log "===== 診断情報収集 完了 ====="
log "出力ファイル: ${ZIP_FILE}"
echo ""
echo "診断ZIPファイル: ${ZIP_FILE}"
echo "サポートへ連絡する際はこのファイルを添付してください"

exit 0
