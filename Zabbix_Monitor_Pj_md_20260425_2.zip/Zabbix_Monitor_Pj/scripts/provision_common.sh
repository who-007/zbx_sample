#!/usr/bin/env bash
# =============================================================================
# scripts/provision_common.sh
# 役割: 共通ネットワーク・ボリューム作成、環境変数チェック
# 使い方: bash scripts/provision_common.sh
# =============================================================================
set -euo pipefail

# ログ設定
LOGDIR="${PWD}/logs"
mkdir -p "${LOGDIR}"
LOGFILE="${LOGDIR}/provision_common.log"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()  { echo "$(timestamp) [provision_common] $*" | tee -a "${LOGFILE}"; }
err()  { echo "$(timestamp) [provision_common] ERROR: $*" | tee -a "${LOGFILE}" >&2; exit 1; }
warn() { echo "$(timestamp) [provision_common] WARN:  $*" | tee -a "${LOGFILE}"; }

log "===== 共通プロビジョニング 開始 ====="

# --- 1. .env チェック ---
if [ ! -f "${PWD}/.env" ]; then
  err ".env ファイルが見つかりません。cp .env.example .env を実行してください。"
fi
log ".env ファイル確認 OK"

# 環境変数読み込み
set -o allexport
# shellcheck source=/dev/null
source "${PWD}/.env"
set +o allexport

# --- 2. 必須環境変数チェック ---
REQUIRED_VARS=(
  PROJECT_NAME
  PROJECT_NETWORK
  MYSQL_ROOT_PASSWORD
  MYSQL_USER
  MYSQL_PASSWORD
  MYSQL_DATABASE
)
for VAR in "${REQUIRED_VARS[@]}"; do
  if [ -z "${!VAR:-}" ]; then
    err "必須環境変数 '${VAR}' が設定されていません。.env を確認してください。"
  fi
done
log "必須環境変数チェック OK"

# --- 3. Docker 動作確認 ---
if ! command -v docker >/dev/null 2>&1; then
  err "docker コマンドが見つかりません。Docker CE がインストールされているか確認してください。"
fi
if ! docker info >/dev/null 2>&1; then
  err "Docker デーモンが起動していません。'sudo service docker start' 等で起動してください。"
fi
log "Docker 動作確認 OK ($(docker --version))"

# --- 4. Docker ネットワーク作成（存在しない場合のみ） ---
NETWORK_NAME="${PROJECT_NETWORK:-zbx-net}"
if docker network inspect "${NETWORK_NAME}" >/dev/null 2>&1; then
  log "Docker ネットワーク '${NETWORK_NAME}' は既に存在します"
else
  docker network create "${NETWORK_NAME}"
  log "Docker ネットワーク '${NETWORK_NAME}' を作成しました"
fi

# --- 5. Docker ボリューム作成（存在しない場合のみ） ---
VOLUMES=(
  "${PROJECT_NAME:-zbx}_dev_db_a"
  "${PROJECT_NAME:-zbx}_dev_db_b"
  "${PROJECT_NAME:-zbx}_prod_db_a"
  "${PROJECT_NAME:-zbx}_prod_db_b"
)
for VOL in "${VOLUMES[@]}"; do
  if docker volume inspect "${VOL}" >/dev/null 2>&1; then
    log "Docker ボリューム '${VOL}' は既に存在します"
  else
    docker volume create "${VOL}"
    log "Docker ボリューム '${VOL}' を作成しました"
  fi
done

# --- 6. secrets/ ディレクトリ作成 ---
if [ ! -d "${PWD}/secrets" ]; then
  mkdir -p "${PWD}/secrets"
  chmod 700 "${PWD}/secrets"
  log "secrets/ ディレクトリを作成しました（パーミッション 700）"
fi

log "===== 共通プロビジョニング 完了 ====="
exit 0
