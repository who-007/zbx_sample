#!/usr/bin/env bash
# =============================================================================
# scripts/prod_setup.sh
# 役割: 実運用環境一括構築（ホスト単位での起動手順）
# 使い方: sudo bash scripts/prod_setup.sh [host-a|host-b|all]
# 引数:
#   host-a : ホストA のみ起動
#   host-b : ホストB のみ起動
#   all    : 両方起動（デフォルト、ただし通常はホスト別に実行）
# 注意: 実運用では各ホスト上でそれぞれ実行してください
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
LOGDIR="${PROJECT_ROOT}/logs"
mkdir -p "${LOGDIR}"
exec > >(tee -a "${LOGDIR}/prod_setup.log") 2>&1

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }
log()  { echo "$(timestamp) [prod_setup] $*"; }
err()  { echo "$(timestamp) [prod_setup] ERROR: $*" >&2; exit 1; }
warn() { echo "$(timestamp) [prod_setup] WARN:  $*"; }

TARGET="${1:-all}"
log "===== 実運用環境 セットアップ 開始 (対象: ${TARGET}) ====="
log "プロジェクトルート: ${PROJECT_ROOT}"

# --- 1. 共通プロビジョニング ---
log "--- Step 1: 共通プロビジョニング ---"
bash "${SCRIPT_DIR}/provision_common.sh" || err "provision_common.sh が失敗しました"

# 環境変数読み込み
set -o allexport
# shellcheck source=/dev/null
source "${PROJECT_ROOT}/.env"
set +o allexport

# --- 2. docker-compose コマンド確認 ---
log "--- Step 2: docker-compose コマンド確認 ---"
COMPOSE_CMD=""
if command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD="docker-compose"
elif docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD="docker compose"
else
  err "docker-compose / docker compose コマンドが見つかりません"
fi

# --- 3. セキュリティチェック ---
log "--- Step 3: セキュリティチェック ---"
# パスワードのデフォルト値チェック
if echo "${MYSQL_ROOT_PASSWORD:-}" | grep -q "ChangeMe"; then
  warn ".env の MYSQL_ROOT_PASSWORD がデフォルト値のままです。本番環境では必ず変更してください！"
fi
if echo "${MYSQL_PASSWORD:-}" | grep -q "ChangeMe"; then
  warn ".env の MYSQL_PASSWORD がデフォルト値のままです。本番環境では必ず変更してください！"
fi

# --- ホストA 起動 ---
start_host_a() {
  log "--- ホストA (監視サーバ) 起動 ---"
  COMPOSE_A="${PROJECT_ROOT}/prod/host-a/docker-compose.yaml"
  [ ! -f "${COMPOSE_A}" ] && err "ファイルが見つかりません: ${COMPOSE_A}"
  ${COMPOSE_CMD} -f "${COMPOSE_A}" --env-file "${PROJECT_ROOT}/.env" up -d --build
  log "ホストA コンテナ起動 完了"
}

# --- ホストB 起動 ---
start_host_b() {
  log "--- ホストB (監視プロキシ) 起動 ---"
  COMPOSE_B="${PROJECT_ROOT}/prod/host-b/docker-compose.yaml"
  [ ! -f "${COMPOSE_B}" ] && err "ファイルが見つかりません: ${COMPOSE_B}"
  ${COMPOSE_CMD} -f "${COMPOSE_B}" --env-file "${PROJECT_ROOT}/.env" up -d --build
  log "ホストB コンテナ起動 完了"
}

# --- 4. 対象ホスト起動 ---
log "--- Step 4: コンテナ起動 ---"
case "${TARGET}" in
  host-a) start_host_a ;;
  host-b) start_host_b ;;
  all)
    start_host_a
    start_host_b
    ;;
  *)
    err "不正な引数: ${TARGET}  使用可能: host-a | host-b | all"
    ;;
esac

# --- 5. サービス起動待ち ---
log "--- Step 5: サービス起動待ち（45秒）---"
log "MySQL/Zabbix Server の初期化を待機しています..."
sleep 45

# --- 6. ヘルスチェック ---
log "--- Step 6: ヘルスチェック実行 ---"
bash "${SCRIPT_DIR}/check_health.sh" || {
  warn "ヘルスチェックで一部失敗があります。logs/check_health.log を確認してください。"
  exit 4
}

# --- 7. 完了メッセージ ---
log "===== 実運用環境 セットアップ 完了 ====="
log ""
log "【確認事項】"
log "  Zabbix Web UI: http://<ホストA-IP>:8080/zabbix"
log "  初回ログイン後、管理者パスワードを変更してください"
log "  ホストA/B の Agent2 ホスト登録を Zabbix Web UI から行ってください"
log "  ヘルスチェック: bash scripts/check_health.sh"
log ""

exit 0
